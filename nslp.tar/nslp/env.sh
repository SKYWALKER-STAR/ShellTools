#!/bin/bash

OUTPUTFILE=`pwd`/result.txt
ENVFILE=`pwd`/env.sh
FUNCTIONFILE=`pwd`/func.sh
